import { Airline } from './airline';

describe('Airline', () => {
  it('should create an instance', () => {
    expect(new Airline()).toBeTruthy();
  });
});
