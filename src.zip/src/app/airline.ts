export class Airline {

    fid:String |undefined;
    fname:String | undefined;
    ffrom:String | undefined;
    fto:String | undefined;
    fclass:String|undefined;
    fprice: String|undefined;
}
